# NewsMonkey

#### About NewsMonkey

NewsMonkey is a platform made from MERN Stack where the users can view daily news, the news are catagorised so that it will be easier for the users to search. News API is used to fetch the news.


### Installation 
---

1. Clone the repository
2. Open with code editor and run following commands on the terminal.
    + ` npm install `
    + ` npm start`
3. Open the localhost link.

